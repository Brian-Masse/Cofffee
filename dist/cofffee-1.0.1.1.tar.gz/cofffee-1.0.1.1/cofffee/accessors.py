# DATASETS:

coffee = "cofffee/data/coffee.xlsx"

# FONTS:

monoid = "cofffee/data/fonts/Monoid-Retina.ttf"
lulo = "cofffee/data/fonts/Lulo Clean One Bold.otf"
din = "cofffee/data/fonts/DIN Condensed Bold.ttf"
fetch = "cofffee/data/fonts/fetchTitleFont.ttf"