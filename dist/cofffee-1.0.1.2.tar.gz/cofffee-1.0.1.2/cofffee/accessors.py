# DATASETS:

coffee = "cofffee/data/coffee.xlsx"

# FONTS:

monoid = "/data/fonts/Monoid-Retina.ttf"
lulo = "/data/fonts/Lulo Clean One Bold.otf"
din = "/data/fonts/DIN Condensed Bold.ttf"
fetch = "/data/fonts/fetchTitleFont.ttf"